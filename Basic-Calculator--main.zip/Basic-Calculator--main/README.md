# Basic-Calculator-
🧮 Simple Python Calculator

This project is a beginner-friendly command-line calculator written in Python. It allows users to perform basic arithmetic operations, including:

  Addition

  Subtraction

  Multiplication

  Division (with handling for division by zero)

How It Works

When the program runs, it prompts the user to select an operation and enter two numbers. Based on the user’s choice, it executes the corresponding function and prints the result.

Features:

  Clean and easy-to-read Python code

  Separate functions for each operation

  Input validation for division by zero

  Interactive command-line interface
